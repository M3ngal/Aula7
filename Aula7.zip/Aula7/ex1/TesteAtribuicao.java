import java.util.Scanner;


public class TesteAtribuicao {
    public static void main (String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Nome do Professor: ");
        String np = sc.nextLine();
        System.out.print("Idade: ");
        int i = Integer.parseInt(sc.nextLine());
        System.out.print("Nome da Disciplina: ");
        String nd = sc.nextLine();
        System.out.print("Praticada: ");
        boolean p = Boolean.parseBoolean(sc.nextLine());

        Professor professor = new Professor(np, i);
        Disciplina disciplina = new Disciplina(nd, p);
        Atribuicao atribuicao = new Atribuicao(professor, disciplina);

        String t1 = professor.getDados();
        String t2 = disciplina.getDados();
        String t3 = atribuicao.getDados();

        System.out.print(t1);
        System.out.print(t2);
        System.out.print(t3);
        System.out.print("\n");

        System.out.print("Nome do Professor: ");
        np = sc.nextLine();
        System.out.print("Idade: ");
        i = Integer.parseInt(sc.nextLine());
        System.out.print("Nome da Disciplina: ");
        nd = sc.nextLine();
        System.out.print("Praticada: ");
        p = Boolean.parseBoolean(sc.nextLine());

        professor.setNome(np);
        professor.setIdade(i);
        disciplina.setNome(nd);
        disciplina.setPratica(p);
        atribuicao.setProfessor(professor);
        atribuicao.setDisciplina(disciplina);

        t1 = professor.getDados();
        t2 = disciplina.getDados();
        t3 = atribuicao.getDados();

        System.out.print(t1);
        System.out.print(t2);
        System.out.print(t3);

        sc.close();
    }
}
