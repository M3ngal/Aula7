public class Professor {
    private String nome;
    private int idade;

    public Professor(String n, int i){
        nome = n;
        idade = i;
    }

    public String getNome(){
        return nome;
    }
    public int getIdade(){
        return idade;
    }
    public String getDados(){
        return("Nome do Professor: " + getNome() + "\nIdade: " + getIdade());
    }

    public void setNome(String n){
        nome = n;
    }
    public void setIdade(int i){
        idade = i;
    }
}