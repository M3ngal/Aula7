package ex2;

public class ContaCorrente {
    private int numero;
    private int digito;
    private Agencia agencia;
    private double saldo;

    public ContaCorrente(int n, int d, Agencia a, double s){
        numero = n;
        digito = d;
        agencia = a;
        saldo = s;
    }

    public static boolean ConfereNumero(int n, int d){
        int ch;
        int so = 0;
        if(n < 0 && n > 9999){
            return(false);
        }
        if(n < 999){
            ch = 0;
        }
        else{
            String cn = n + "";
            ch = Integer.parseInt(cn.substring(0,1));
            so += (ch * 4);
        }
        if(n < 99){
            ch = 0;
        }
        else{
            String cn = n + "";
            ch = Integer.parseInt(cn.substring(1,2));
            so += (ch * 6);
        }
        if(n < 9){
            ch = 0;
        }
        else{
            String cn = n + "";
            ch = Integer.parseInt(cn.substring(2,3));
            so += (ch * 8);
        }
        String cn = n + "";
        ch = Integer.parseInt(cn.substring(3,4));
        so += (ch * 2);
        so = so % 11;
        if(so == 10){
            so = 0;
        }
        if(d == so){
            return true;
        }
        else{
            return false;
        }
    }

    public int getNumero(){
        return numero;
    }
    public int getDigito(){
        return digito;
    }
    public Agencia getAgencia(){
        return agencia;
    }
    public double getSaldo(){
        return saldo;
    }

    public void setNumero(int n){
        numero = n;
    }
    public void setDigito(int d){
        digito = d;
    }
    public void setAgencia(Agencia a){
        agencia = a;
    }
    public void setSaldo(double s){
        saldo = s;
    }

    public double depositar(double s){
        saldo += s;
        return saldo;
    }
    public double sacar(double s){
        double c = saldo;
        saldo -= s;
        if(saldo < 0) {
            System.out.print("Saldo indisponível para saque.\n");
            saldo = c;
            return 0;
        }
        else{
            return saldo;
        }
    }
    public double consultarSaldo(){
        return saldo;
    }
    public void imprimirSaldo(int n, int d, int na, int da, double saldo){
        System.out.print("Conta corrente: " + n + " Dígito: " + d +"\nAgência: " + na + " Dígito: " + da +"\nSaldo da conta corrente: " + saldo);
    }
}
