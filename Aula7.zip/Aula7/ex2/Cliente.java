package ex2;

public class Cliente {
    private String nome;
    private String cpf;
    private ContaCorrente conta;

    public Cliente(String n, String c, ContaCorrente ct){
        nome = n;
        cpf = c;
        conta = ct;
    }

    public String getNome(){
        return nome;
    }
    public String getCpf(){
        return cpf;
    }
    public ContaCorrente getConta(){
        return conta;
    }

    public void setNome(String n){
        nome = n;
    }
    public void setCpf(String c){
        cpf = c;
    }
    public void setConta(ContaCorrente ct){
        conta = ct;
    }
}