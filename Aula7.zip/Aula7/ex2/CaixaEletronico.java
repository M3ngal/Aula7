package ex2;
import java.util.Scanner;

public class CaixaEletronico {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int nuc;
        int dc;
        System.out.print("Nome: ");
        String nc = sc.nextLine();
        System.out.print("CPF: ");
        String cpf = sc.nextLine();
        while(true) {
            System.out.print("Conta Corrente: ");
            nuc = Integer.parseInt(sc.nextLine());
            System.out.print("Digito: ");
            dc = Integer.parseInt(sc.nextLine());
            if(ContaCorrente.ConfereNumero(nuc, dc)){
                break;
            }
        }
        System.out.print("Nome da Agencia: ");
        String na = sc.nextLine();
        System.out.print("Agencia: ");
        int nua = Integer.parseInt(sc.nextLine());
        System.out.print("Digito: ");
        int da = Integer.parseInt(sc.nextLine());

        System.out.print("Saldo da Conta: ");
        double s = Double.parseDouble(sc.nextLine());


        Agencia agencia = new Agencia(na, nua, da);
        ContaCorrente contaCorrente = new ContaCorrente(nuc, dc, agencia, s);
        Cliente cliente = new Cliente(nc, cpf, contaCorrente);

        while(true){
            System.out.print("Operacoes: \n");
            System.out.print("1 - Sacar\n");
            System.out.print("2 - Depositar\n");
            System.out.print("3 - Consultar saldo\n");
            System.out.print("4 - Imprimir saldo\n");
            int ca = Integer.parseInt(sc.nextLine());
            double sal;
            int b = 0;
            switch(ca){
                case 1:{
                    System.out.print("Quantidade a sacar: ");
                    sal = Double.parseDouble(sc.nextLine());
                    contaCorrente.sacar(sal);
                    break;
                }
                case 2:{
                    System.out.print("Quantidade a depositar: ");
                    sal = Double.parseDouble(sc.nextLine());
                    contaCorrente.depositar(sal);
                    break;
                }
                case 3:{
                    System.out.print("Saldo: " + contaCorrente.consultarSaldo() + "\n");
                    break;
                }
                case 4:{
                    System.out.print(cliente.getNome() + "\n");
                    System.out.print(cliente.getCpf() + "\n");
                    contaCorrente.imprimirSaldo(nuc, dc, nua, da, contaCorrente.consultarSaldo());
                    b = 1;
                    break;
                }

            }
            if(b == 1){
                break;
            }
        }

        sc.close();
    }
}