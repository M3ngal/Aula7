package ex2;

public class Agencia {
    private String nome;
    private int numero;
    private int digito;

    public Agencia(String n, int nu, int d){
        nome = n;
        numero = nu;
        digito = d;
    }

    public String getNome(){
        return nome;
    }
    public int getNumero(){
        return numero;
    }
    public int getDigito(){
        return digito;
    }

    public void setNome(String n){
        nome = n;
    }
    public void setNumero(int nu){
        numero = nu;
    }
    public void setDigito(int d){
        digito = d;
    }
}