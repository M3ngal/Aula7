package ex3;

public class Termostato {
    private int temperatura;

    public Termostato(){
        temperatura = 20;
    }

    public int getTemperatura(){
        return temperatura;
    }

        public void setTemperatura(int t){
        temperatura = t;
    }
}
