package ex3;

public class CondicionadorDeAr {
    private boolean ligado;
    private Termostato termostato;

    public CondicionadorDeAr(){
        termostato = new Termostato();
        ligado = false;
    }

        public Termostato getTermostato(){
        return termostato;
    }
    public boolean getLigado(){
        return ligado;
    }

    public void ligar(){
        ligado = true;
    }
    public void desligar(){
        ligado = false;
    }
    public void aumentaTemperatura(){
        if(getLigado() == false){
            System.out.print("Condicionador nao esta ligado.\n");
        }
        else {
            if (termostato.getTemperatura() < 28) {
                termostato.setTemperatura((termostato.getTemperatura() + 1));
            } else {
                System.out.print("Temperatura maxima.\n");
            }
        }
    }
    public void diminuirTemperatura(){
        if(getLigado() == false){
            System.out.print("Condicionador nao esta ligado.\n");
        }
        else{
            if(termostato.getTemperatura() > 15){
                termostato.setTemperatura((termostato.getTemperatura() - 1));
            }
            else{
                System.out.print("Temperatura minima.\n");
            }
        }
    }
    public void imprimirTemperatura(){
        if(getLigado() == false){
            System.out.print("Condicionador nao esta ligado.\n");
        }
        else {
            System.out.print("Temperatura atual: " + termostato.getTemperatura() + "\n");
        }
    }

}