package ex3;
import java.util.Scanner;

public class Usuario {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CondicionadorDeAr condicionadorDeAr = new CondicionadorDeAr();
        while(true){
            if(condicionadorDeAr.getLigado() == false){
                System.out.print("Status: Desligado\n");
            }
            else{
                System.out.print("Status: Ligado\n");
            }
            System.out.print("Operacoes: \n");
            System.out.print("1 - Ligar\n");
            System.out.print("2 - Desligar\n");
            System.out.print("3 - Aumentar a temperatura\n");
            System.out.print("4 - Diminuir a temperatura\n");
            System.out.print("5 - Consultar a temperatura\n");
            System.out.print("6 - Sair\n");
            int ca = Integer.parseInt(sc.nextLine());
            int r;
            int b = 0;
            switch(ca){
                case 1:{
                    condicionadorDeAr.ligar();
                    break;
                }
                case 2:{
                    condicionadorDeAr.desligar();
                    break;
                }
                case 3:{
                    condicionadorDeAr.aumentaTemperatura();
                    break;
                }
                case 4:{
                    condicionadorDeAr.diminuirTemperatura();
                    break;
                }
                case 5:{
                    condicionadorDeAr.imprimirTemperatura();
                    break;
                }
                case 6:{
                    b = 1;
                    break;
                }
            }
            if(b == 1){
                break;
            }
        }
        sc.close();
    }
}
